#encoding=utf-8
#构建补丁包生成工具,在当前目录生成补丁包
import base64
import hashlib
import json
import os
import zipfile
import subprocess

import sys

class BuildHotFix:
    #当前文件所在目录
    __nowDirPath = ""
    __jarPath = ""
    __dexPath = ""
    __infoPath = ""
    __resDirPath = ""

    def __init__(self):
        self.initPath()
        return

    def initPath(self):
        "初始化路径信息"
        self.__nowDirPath = os.path.dirname(__file__)
        self.__jarPath = self.__nowDirPath + "/tmp.jar"
        self.__dexPath = self.__nowDirPath + "/patch.jar"
        self.__infoPath = self.__nowDirPath + "/info"
        self.__resDirPath = self.__nowDirPath + "/res"
        return

    def doBuildJar(self):
        "开始打jar包"
        popen = subprocess.Popen("jar cvf tmp.jar com", shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 cwd=self.__nowDirPath,
                                 bufsize=1)
        while popen.poll() is None:  # None表示正在执行中
            r = popen.stdout.readline().decode("utf-8").encode('utf-8')
            sys.stdout.write(str(r))  # 输出编译内容

        if os.path.exists(self.__jarPath):
            print("生成tmp.jar成功！")
            return True
            os.system("dx --dex --output=patch.jar tmp.jar")
        else:
            print("生成tmp.jar失败！")
            return False

    def doBuildDex(self):
        "开始打jar包"
        popen = subprocess.Popen("dx --dex --output=patch.jar tmp.jar", shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 cwd=self.__nowDirPath,
                                 bufsize=1)
        while popen.poll() is None:  # None表示正在执行中
            r = popen.stdout.readline().decode("utf-8").encode('utf-8')
            sys.stdout.write(str(r))  # 输出编译内容
        if os.path.exists(self.__dexPath):
            print("生成patch.jar成功！")
            return True
        else:
            print("生成patch.jar失败！")
            return False

    def doCreatePatchInfoFile(self):
        "生成插件信息文件"
        patchMd5 = self.getFileMd5(self.__dexPath)
        print("补丁包文件的MD5：" + patchMd5)
        fileNames = []
        if os.path.exists(self.__resDirPath):#存在res文件
            for file in os.listdir(self.__resDirPath):
                fileNames.append(file)
        #生成json串
        verifyBean = VerifyBean(patchMd5,fileNames)
        verifyBeanJsonStr = verifyBean.getJsonStr()
        print("校验文件json串："+verifyBeanJsonStr)
        #base64编码
        verifyBeanBase64Str = str(base64.b64encode(verifyBeanJsonStr.encode("utf-8"))) + "0"
        print("校验文件base64串：" + verifyBeanBase64Str)
        #将串写入文件
        foutput = open(self.__infoPath,"w")
        foutput.write(verifyBeanBase64Str)
        foutput.flush()
        foutput.close()
        print("生成info校验文件成功")
        return

    def getFileMd5(self,filename):
        "获取文件MD5值"
        if not os.path.isfile(filename):
            return
        md5Hash = hashlib.md5()
        f = open(filename, 'rb')
        while True:
            b = f.read(8096)
            if not b:
                break
            md5Hash.update(b)
        f.close()
        return md5Hash.hexdigest()

    def doBuildPatchJar(self):
        "打包zip"
        patchZipFile = "patch.zip"
        cmd = "zip -r -o \'" + patchZipFile + "\' \'res\' \'info\' \'patch.jar\'"
        print(cmd)
        popen = subprocess.Popen(cmd, shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 cwd=self.__nowDirPath,
                                 bufsize=1)
        while popen.poll() is None:  # None表示正在执行中
            r = popen.stdout.readline().decode("utf-8").encode('utf-8')
            sys.stdout.write(str(r))  # 输出编译内容
        if os.path.exists(self.__nowDirPath+"/patch.zip"):
            print("补丁打包成功！")
        else:
            print("补丁打包失败")
        return

    def cleanTmpFile(self):
        "清理临时文件"
        os.remove(self.__dexPath)
        os.remove(self.__jarPath)
        os.remove(self.__infoPath)
        #重命名补丁包
        patchName = self.getFileMd5(self.__nowDirPath+"/patch.zip")+".jar"
        os.rename(self.__nowDirPath+"/patch.zip",self.__nowDirPath+"/"+patchName)
        if os.path.exists(self.__nowDirPath+"/"+patchName):
            print("补丁构建结束======>补丁包"+patchName)
        return

    def doBuild(self):
        "开始构建流程"
        print("开始构建补丁包！")
        if not self.doBuildJar():
            return

        if not self.doBuildDex():
            return

        self.doCreatePatchInfoFile()

        self.doBuildPatchJar()

        self.cleanTmpFile()
        return


class VerifyBean:
    patchMd5 = ""
    resList = []

    def __init__(self,patchMd5,resList):
        self.patchMd5 = patchMd5
        self.resList = resList
        return

    def __dateEncode(self,obj):
        return {
            "patchMd5": obj.patchMd5,
            "resList": obj.resList
        }

    def getJsonStr(self):
        "获取json串"
        return json.dumps(self,default=self.__dateEncode)


#*************命令行执行**********
buildHotFix = BuildHotFix()
buildHotFix.doBuild()